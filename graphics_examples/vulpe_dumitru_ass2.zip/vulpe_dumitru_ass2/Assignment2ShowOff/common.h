#ifndef COMMON
#define COMMON
	#include <glload/gl_4_0.h>
	#include <glload/gl_load.h>
	#include <GLFW/glfw3.h>

	#include <glm/glm.hpp>
	#include <glm/gtc/matrix_transform.hpp>
	#include <glm/gtc/type_ptr.hpp>
#endif 